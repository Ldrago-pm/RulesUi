# RulesUI
A PocketMine-MP plugin that make sure players is accepted with all Rules in your server!
